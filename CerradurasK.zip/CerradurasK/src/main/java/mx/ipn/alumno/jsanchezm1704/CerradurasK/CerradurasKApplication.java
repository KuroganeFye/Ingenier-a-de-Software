package mx.ipn.alumno.jsanchezm1704.CerradurasK;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CerradurasKApplication {

	public static void main(String[] args) {
		SpringApplication.run(CerradurasKApplication.class, args);
	}

}
