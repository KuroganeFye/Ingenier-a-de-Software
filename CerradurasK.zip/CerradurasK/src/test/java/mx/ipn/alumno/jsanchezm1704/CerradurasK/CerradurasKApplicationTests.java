package mx.ipn.alumno.jsanchezm1704.CerradurasK;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CerradurasKApplicationTests {

	@Test
	void contextLoads() {
	}

}
